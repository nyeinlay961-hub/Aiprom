import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  Bookmark, 
  Sparkles, 
  Download, 
  Smartphone, 
  FileText, 
  Cpu, 
  Clock,
  Layers
} from 'lucide-react';
import { estimateTokens } from '../utils/promptUtils';
import type { PromptData } from '../types/prompt';

interface PromptPreviewProps {
  assembledPrompt: string;
  data: PromptData;
  onOpenSaveModal: () => void;
  onOpenTestModal: () => void;
  onOpenApkModal: () => void;
}

export const PromptPreview: React.FC<PromptPreviewProps> = ({
  assembledPrompt,
  data,
  onOpenSaveModal,
  onOpenTestModal,
  onOpenApkModal,
}) => {
  const [copied, setCopied] = useState(false);
  const stats = estimateTokens(assembledPrompt);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(assembledPrompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy to clipboard', err);
    }
  };

  const handleDownloadMarkdown = () => {
    const blob = new Blob([assembledPrompt], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prompt-${data.role.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'prompt'}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Live Preview Header & Stats */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Assembled System Prompt
            </h3>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-indigo-400 font-mono">
            <Cpu className="w-3.5 h-3.5" />
            <span>Gemini Ready</span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2 p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 text-center text-xs">
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Tokens</div>
            <div className="text-base font-extrabold text-indigo-400 font-mono">
              ~{stats.tokens.toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Words</div>
            <div className="text-base font-extrabold text-slate-200 font-mono">
              {stats.words.toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Characters</div>
            <div className="text-base font-extrabold text-slate-200 font-mono">
              {stats.characters.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Code Text Area */}
      <div className="flex-1 relative rounded-xl border border-slate-800 bg-slate-950/95 overflow-hidden flex flex-col min-h-[350px]">
        {/* Top toolbar inside editor */}
        <div className="px-4 py-2 border-b border-slate-800/80 bg-slate-900/60 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-400">markdown-system-prompt.md</span>
          <div className="flex items-center gap-1">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition"
              title="Copy to clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy</span>
                </>
              )}
            </button>
            <button
              onClick={handleDownloadMarkdown}
              className="flex items-center gap-1 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition"
              title="Download Markdown file"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Assembled Content */}
        <div className="p-4 flex-1 overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap select-text">
          {assembledPrompt || (
            <span className="text-slate-600 italic">
              Your assembled prompt will appear here as you configure the persona, task, and constraints.
            </span>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
        <button
          type="button"
          onClick={onOpenTestModal}
          className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/25 transition active:scale-98"
        >
          <Sparkles className="w-4 h-4 text-indigo-200" />
          <span>Test Live with Gemini AI</span>
        </button>

        <button
          type="button"
          onClick={onOpenSaveModal}
          className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm border border-slate-700 transition active:scale-98"
        >
          <Bookmark className="w-4 h-4 text-slate-400" />
          <span>Save to Prompt Library</span>
        </button>
      </div>

      {/* Featured Android APK Card */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-teal-950/30 border border-emerald-500/30 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
            <Smartphone className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-200">
              Ready to deploy on Android?
            </div>
            <div className="text-[11px] text-slate-400">
              Compile to native APK or install as an Android WebAPK instantly.
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenApkModal}
          className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 shadow-md transition active:scale-95"
        >
          Build APK
        </button>
      </div>
    </div>
  );
};
