import React, { useState } from 'react';
import { Bookmark, X, Tag, Folder, FileText } from 'lucide-react';
import type { PromptData, SavedPrompt } from '../types/prompt';

interface SavePromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: PromptData;
  assembledPrompt: string;
  onSave: (saved: SavedPrompt) => void;
}

export const SavePromptModal: React.FC<SavePromptModalProps> = ({
  isOpen,
  onClose,
  data,
  assembledPrompt,
  onSave,
}) => {
  const [title, setTitle] = useState(data.role || 'New System Prompt');
  const [category, setCategory] = useState('development');
  const [tagsInput, setTagsInput] = useState(data.tags.join(', '));
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    const newSaved: SavedPrompt = {
      id: Date.now().toString(),
      title: title.trim(),
      data,
      assembledPrompt,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      category,
      favorite: false,
      tags,
      notes: notes.trim() || undefined,
    };

    onSave(newSaved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-6 text-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-slate-100">Save to Library</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Prompt Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Android Kotlin Architecture Spec"
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:border-indigo-500"
            >
              <option value="development">Development & Engineering</option>
              <option value="marketing">Marketing & Copywriting</option>
              <option value="analysis">Analysis & Research</option>
              <option value="system">System & Meta-Prompt</option>
              <option value="general">General</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Tags (comma separated)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="android, kotlin, pwa, mobile"
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Private Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Any usage reminders or testing notes..."
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-md"
            >
              Save Prompt
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
