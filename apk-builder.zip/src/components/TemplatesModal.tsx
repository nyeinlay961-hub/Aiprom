import React, { useState } from 'react';
import { 
  LayoutTemplate, 
  ArrowRight, 
  X, 
  Sparkles, 
  Check, 
  Search,
  Code2,
  TrendingUp,
  Cpu,
  Smartphone,
  BookOpen
} from 'lucide-react';
import { PRESET_TEMPLATES } from '../data/presets';
import type { PresetTemplate, PromptData } from '../types/prompt';

interface TemplatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: PresetTemplate) => void;
}

const CATEGORIES = ['All', 'development', 'marketing', 'analysis', 'system'];

export const TemplatesModal: React.FC<TemplatesModalProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
}) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const filtered = PRESET_TEMPLATES.filter((tpl) => {
    const matchesSearch = 
      tpl.name.toLowerCase().includes(search.toLowerCase()) ||
      tpl.description.toLowerCase().includes(search.toLowerCase()) ||
      tpl.data.tags.some(t => t.toLowerCase().includes(search.toLowerCase()));

    if (!matchesSearch) return false;
    if (selectedCategory === 'All') return true;
    return tpl.category === selectedCategory;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-3xl my-8 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <LayoutTemplate className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-100">
                Curated Prompt Templates
              </h3>
              <p className="text-xs text-slate-400">
                Battle-tested system prompt architectures for software, Android, marketing, and analysis.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/40 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter templates..."
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500"
          />
        </div>

        {/* Templates List */}
        <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((tpl) => (
            <div
              key={tpl.id}
              className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-indigo-500/50 flex flex-col justify-between transition group space-y-3"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    {tpl.badge}
                  </span>
                  <span className="text-[11px] text-slate-500 capitalize">
                    {tpl.category}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-slate-100 group-hover:text-indigo-300 transition mb-1">
                  {tpl.name}
                </h4>

                <p className="text-xs text-slate-400 leading-relaxed mb-3">
                  {tpl.description}
                </p>

                <div className="flex flex-wrap gap-1">
                  {tpl.data.tags.map((t, idx) => (
                    <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-800/80 text-slate-400">
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  onSelectTemplate(tpl);
                  onClose();
                }}
                className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-98"
              >
                <span>Load Template into Studio</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
