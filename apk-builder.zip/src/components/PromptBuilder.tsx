import React, { useState } from 'react';
import { 
  UserCheck, 
  Target, 
  BookOpen, 
  ShieldAlert, 
  FileCode2, 
  Plus, 
  Trash2, 
  Sparkles, 
  Sliders, 
  HelpCircle,
  Lightbulb,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import type { PromptData, QualityScore } from '../types/prompt';

interface PromptBuilderProps {
  data: PromptData;
  onChange: (updated: PromptData) => void;
  qualityScore: QualityScore;
  onApplyPreset: () => void;
}

const ROLE_SUGGESTIONS = [
  'Senior Principal Software Architect',
  'Lead Android Mobile Developer',
  'B2B SaaS Growth Copywriter',
  'Senior Cyber Security Auditor',
  'Machine Learning & Data Scientist',
  'Academic Journal Peer Reviewer',
  'UI/UX Design Systems Specialist'
];

const TONE_SUGGESTIONS = [
  'Professional & Authoritative',
  'Concise & Direct',
  'Technical & Rigorous',
  'Empathetic & Conversational',
  'Analytical & Objective',
  'Instructive & Socratic'
];

const FORMAT_SUGGESTIONS = [
  'Markdown with structured headers & code snippets',
  'Valid JSON schema with TypeScript interfaces',
  'Comparative matrix table with trade-offs',
  'Numbered step-by-step implementation guide',
  'Executive summary with 3 key pillars & risks'
];

const CONSTRAINT_PRESETS = [
  'No third-party dependencies when native solutions exist',
  'Always include strict type annotations and error checks',
  'Avoid filler phrases and marketing hype words',
  'Provide working code without ellipses or placeholders',
  'Explain the "Why" behind critical architectural trade-offs'
];

export const PromptBuilder: React.FC<PromptBuilderProps> = ({
  data,
  onChange,
  qualityScore,
  onApplyPreset
}) => {
  const [newConstraint, setNewConstraint] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);

  const updateField = <K extends keyof PromptData>(field: K, value: PromptData[K]) => {
    onChange({
      ...data,
      [field]: value
    });
  };

  const handleAddConstraint = (textToAdd?: string) => {
    const text = (textToAdd || newConstraint).trim();
    if (!text) return;
    if (data.constraints.includes(text)) return;
    updateField('constraints', [...data.constraints, text]);
    if (!textToAdd) setNewConstraint('');
  };

  const handleRemoveConstraint = (index: number) => {
    const updated = data.constraints.filter((_, i) => i !== index);
    updateField('constraints', updated);
  };

  const handleAddExample = () => {
    const newEx = {
      id: Date.now().toString(),
      input: '',
      output: ''
    };
    updateField('examples', [...data.examples, newEx]);
  };

  const handleUpdateExample = (id: string, key: 'input' | 'output', value: string) => {
    const updated = data.examples.map(ex => {
      if (ex.id === id) {
        return { ...ex, [key]: value };
      }
      return ex;
    });
    updateField('examples', updated);
  };

  const handleRemoveExample = (id: string) => {
    updateField('examples', data.examples.filter(ex => ex.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Quality Score Bar */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Prompt Quality Audit
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-base font-extrabold ${
              qualityScore.overall >= 80 
                ? 'text-emerald-400' 
                : qualityScore.overall >= 60 
                ? 'text-amber-400' 
                : 'text-rose-400'
            }`}>
              {qualityScore.overall}/100
            </span>
            <span className="text-xs text-slate-400">
              ({qualityScore.overall >= 80 ? 'Production Ready' : qualityScore.overall >= 60 ? 'Moderate' : 'Needs Polish'})
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden mb-3">
          <div 
            className={`h-full transition-all duration-500 rounded-full ${
              qualityScore.overall >= 80 
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400' 
                : qualityScore.overall >= 60 
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400' 
                : 'bg-gradient-to-r from-rose-500 to-orange-400'
            }`}
            style={{ width: `${qualityScore.overall}%` }}
          />
        </div>

        {/* Metrics mini grid */}
        <div className="grid grid-cols-4 gap-2 text-center text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
          <div>
            <div className="font-semibold text-slate-200">{qualityScore.clarity}%</div>
            <div>Clarity</div>
          </div>
          <div>
            <div className="font-semibold text-slate-200">{qualityScore.specificity}%</div>
            <div>Specificity</div>
          </div>
          <div>
            <div className="font-semibold text-slate-200">{qualityScore.context}%</div>
            <div>Context</div>
          </div>
          <div>
            <div className="font-semibold text-slate-200">{qualityScore.structure}%</div>
            <div>Structure</div>
          </div>
        </div>

        {/* Actionable suggestions */}
        {qualityScore.suggestions.length > 0 && (
          <div className="mt-3 p-2.5 rounded-lg bg-indigo-950/30 border border-indigo-500/20 text-xs text-indigo-200 space-y-1">
            <div className="flex items-center gap-1.5 font-medium text-indigo-300">
              <Lightbulb className="w-3.5 h-3.5 text-indigo-400" />
              <span>Recommendations to optimize performance:</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 text-slate-300 text-[11px]">
              {qualityScore.suggestions.map((sug, i) => (
                <li key={i}>{sug}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Section 1: Role & Identity */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <UserCheck className="w-4 h-4 text-indigo-400" />
            <span>AI Role & Persona</span>
          </label>
          <span className="text-xs text-slate-500">Who should the AI act as?</span>
        </div>
        <input
          type="text"
          value={data.role}
          onChange={(e) => updateField('role', e.target.value)}
          placeholder="e.g. Senior Principal Cloud & Android Mobile Architect"
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm text-slate-100 placeholder-slate-500 transition"
        />
        {/* Quick Suggestions Chips */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {ROLE_SUGGESTIONS.slice(0, 4).map((role) => (
            <button
              key={role}
              type="button"
              onClick={() => updateField('role', role)}
              className="text-[11px] px-2.5 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition"
            >
              + {role}
            </button>
          ))}
        </div>
      </div>

      {/* Section 2: Objective & Task */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <Target className="w-4 h-4 text-emerald-400" />
            <span>Primary Objective & Task</span>
          </label>
          <span className="text-xs text-slate-500">Core action request</span>
        </div>
        <textarea
          rows={3}
          value={data.task}
          onChange={(e) => updateField('task', e.target.value)}
          placeholder="Describe the primary goal in explicit detail (e.g. Build an Android APK WebView container with offline caching, Material 3 theme, and smooth refresh)..."
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm text-slate-100 placeholder-slate-500 transition resize-y"
        />
      </div>

      {/* Section 3: Background & Context */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <BookOpen className="w-4 h-4 text-sky-400" />
            <span>Context & Domain Background</span>
          </label>
          <span className="text-xs text-slate-500">Environment & data info</span>
        </div>
        <textarea
          rows={2}
          value={data.context}
          onChange={(e) => updateField('context', e.target.value)}
          placeholder="Provide necessary background, target operating system versions, current stack constraints, or user demographics..."
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm text-slate-100 placeholder-slate-500 transition resize-y"
        />
      </div>

      {/* Section 4: Negative Constraints & Boundaries */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Constraints & Negative Rules</span>
          </label>
          <span className="text-xs text-slate-500">What to strictly avoid</span>
        </div>

        {/* Existing constraints */}
        <div className="space-y-1.5">
          {data.constraints.map((constraint, index) => (
            <div 
              key={index}
              className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900/80 border border-slate-800 text-xs text-slate-200 group"
            >
              <div className="flex items-center gap-2 pr-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>{constraint}</span>
              </div>
              <button
                type="button"
                onClick={() => handleRemoveConstraint(index)}
                className="text-slate-500 hover:text-rose-400 transition p-1"
                title="Remove constraint"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Add constraint input */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={newConstraint}
            onChange={(e) => setNewConstraint(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddConstraint())}
            placeholder="Add constraint (e.g. Do not include mock data)..."
            className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-indigo-500 text-xs text-slate-100 placeholder-slate-500 transition"
          />
          <button
            type="button"
            onClick={() => handleAddConstraint()}
            className="flex items-center gap-1 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </div>

        {/* Constraint presets */}
        <div className="flex flex-wrap gap-1 pt-1">
          {CONSTRAINT_PRESETS.map((cp, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleAddConstraint(cp)}
              className="text-[10px] px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 transition"
            >
              + {cp}
            </button>
          ))}
        </div>
      </div>

      {/* Section 5: Tone & Output Format */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Tone */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">
            Tone & Style
          </label>
          <input
            type="text"
            value={data.tone}
            onChange={(e) => updateField('tone', e.target.value)}
            placeholder="e.g. Professional & Direct"
            className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-indigo-500 text-xs text-slate-100 placeholder-slate-500 transition"
          />
          <div className="flex flex-wrap gap-1 pt-1">
            {TONE_SUGGESTIONS.slice(0, 3).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => updateField('tone', t)}
                className="text-[10px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Target Audience */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">
            Target Audience
          </label>
          <input
            type="text"
            value={data.targetAudience}
            onChange={(e) => updateField('targetAudience', e.target.value)}
            placeholder="e.g. Senior Developers & Android Engineers"
            className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-indigo-500 text-xs text-slate-100 placeholder-slate-500 transition"
          />
        </div>
      </div>

      {/* Section 6: Output Format */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <FileCode2 className="w-4 h-4 text-purple-400" />
            <span>Output Format & Specification</span>
          </label>
          <span className="text-xs text-slate-500">Structure requirement</span>
        </div>
        <input
          type="text"
          value={data.outputFormat}
          onChange={(e) => updateField('outputFormat', e.target.value)}
          placeholder="e.g. Markdown with step-by-step instructions and code blocks"
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-indigo-500 text-sm text-slate-100 placeholder-slate-500 transition"
        />
        <div className="flex flex-wrap gap-1.5 pt-1">
          {FORMAT_SUGGESTIONS.map((fmt, i) => (
            <button
              key={i}
              type="button"
              onClick={() => updateField('outputFormat', fmt)}
              className="text-[10px] px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-750 transition"
            >
              {fmt}
            </button>
          ))}
        </div>
      </div>

      {/* Section 7: Few-Shot Examples (Collapsible) */}
      <div className="border border-slate-800 rounded-xl bg-slate-900/50 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <span>Few-Shot Learning Examples</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-400 font-bold">
                {data.examples.length}
              </span>
            </h4>
            <p className="text-[11px] text-slate-400">
              Provide input/output pairs to prime the LLM for exact patterns.
            </p>
          </div>
          <button
            type="button"
            onClick={handleAddExample}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Example</span>
          </button>
        </div>

        {data.examples.map((ex, idx) => (
          <div key={ex.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 relative">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="font-semibold text-indigo-300">Example #{idx + 1}</span>
              <button
                type="button"
                onClick={() => handleRemoveExample(ex.id)}
                className="text-slate-500 hover:text-rose-400 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <textarea
              rows={2}
              value={ex.input}
              onChange={(e) => handleUpdateExample(ex.id, 'input', e.target.value)}
              placeholder="Input example..."
              className="w-full px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 text-xs text-slate-100 placeholder-slate-500"
            />
            <textarea
              rows={2}
              value={ex.output}
              onChange={(e) => handleUpdateExample(ex.id, 'output', e.target.value)}
              placeholder="Expected output example..."
              className="w-full px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 text-xs text-slate-100 placeholder-slate-500"
            />
          </div>
        ))}
      </div>

      {/* Advanced Parameters Toggle */}
      <div className="pt-2">
        <button
          type="button"
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-medium"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>{showAdvanced ? 'Hide Advanced Parameters' : 'Show Advanced Parameters (Temperature, Reasoning)'}</span>
        </button>

        {showAdvanced && (
          <div className="mt-3 p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span>Creativity / Temperature</span>
                <span className="font-mono text-indigo-400 font-bold">{data.temperature}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={data.temperature}
                onChange={(e) => updateField('temperature', parseFloat(e.target.value))}
                className="w-full accent-indigo-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0.0 (Deterministic / Code)</span>
                <span>0.5 (Balanced)</span>
                <span>1.0 (Creative / Exploratory)</span>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-300 mb-1.5">Reasoning Effort</div>
              <div className="grid grid-cols-3 gap-2">
                {(['low', 'medium', 'high'] as const).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => updateField('reasoningEffort', level)}
                    className={`py-1.5 rounded-lg text-xs font-semibold capitalize transition ${
                      data.reasoningEffort === level
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
