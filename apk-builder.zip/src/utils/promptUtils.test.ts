import test from 'node:test';
import assert from 'node:assert/strict';
import { assemblePrompt, calculateQualityScore, estimateTokens } from './promptUtils.ts';
import type { PromptData } from '../types/prompt.ts';

test('assemblePrompt correctly builds structured prompt with all sections', () => {
  const sampleData: PromptData = {
    role: 'Staff Principal Engineer',
    task: 'Design a resilient distributed event broker using Apache Kafka and Redis.',
    context: 'The system processes 50,000 requests per second across 3 multi-cloud regions.',
    tone: 'Technical, authoritative, and concise',
    constraints: [
      'Zero message loss under partition failure',
      'End-to-end latency below 20ms'
    ],
    outputFormat: 'Structured markdown specification with architectural trade-offs table',
    examples: [
      {
        id: '1',
        input: 'Failover scenario for Broker 2',
        output: 'In-sync replica partition leader switches within 150ms without duplicate delivery'
      }
    ],
    targetAudience: 'Lead backend engineers and SREs',
    temperature: 0.2,
    reasoningEffort: 'high',
    tags: ['system-design', 'distributed-systems']
  };

  const assembled = assemblePrompt(sampleData);

  assert.match(assembled, /ROLE & IDENTITY/);
  assert.match(assembled, /Staff Principal Engineer/);
  assert.match(assembled, /OBJECTIVE & TASK/);
  assert.match(assembled, /CONTEXT & BACKGROUND/);
  assert.match(assembled, /TARGET AUDIENCE/);
  assert.match(assembled, /CONSTRAINTS & NEGATIVE PROMPTS/);
  assert.match(assembled, /OUTPUT FORMAT & SPECIFICATION/);
  assert.match(assembled, /FEW-SHOT EXAMPLES/);
  assert.match(assembled, /REASONING INSTRUCTIONS/);
});

test('estimateTokens calculates words, characters and positive token counts', () => {
  const text = 'Design an optimal caching layer for GraphQL microservices with Redis.';
  const stats = estimateTokens(text);

  assert.equal(stats.words, 10);
  assert.ok(stats.characters > 50);
  assert.ok(stats.tokens > 10);

  const emptyStats = estimateTokens('');
  assert.equal(emptyStats.words, 0);
  assert.equal(emptyStats.characters, 0);
  assert.equal(emptyStats.tokens, 0);
});

test('calculateQualityScore produces reliable score breakdown and helpful suggestions', () => {
  const minimalData: PromptData = {
    role: '',
    task: 'Fix code',
    context: '',
    tone: '',
    constraints: [],
    outputFormat: '',
    examples: [],
    targetAudience: '',
    temperature: 0.7,
    reasoningEffort: 'low',
    tags: []
  };

  const minScore = calculateQualityScore(minimalData, assemblePrompt(minimalData));
  assert.ok(minScore.overall < 60, 'Minimal prompt should have low quality score');
  assert.ok(minScore.suggestions.length > 0, 'Suggestions should be provided');

  const comprehensiveData: PromptData = {
    role: 'Senior Security Auditor',
    task: 'Analyze the smart contract for reentrancy vulnerabilities and evaluate gas efficiency.',
    context: 'The Solidity contract is deployed on Arbitrum handling pooled staking deposits.',
    tone: 'Rigorous and audit-grade',
    constraints: [
      'Highlight critical CVSS scores',
      'Provide concrete remediation code patches',
      'Do not include theoretical attacks that are patched by SafeMath'
    ],
    outputFormat: 'Formal audit report with severity findings table and remediation steps',
    examples: [
      {
        id: '1',
        input: 'withdraw() function reentrancy',
        output: 'Fix with CEI pattern (Checks-Effects-Interactions) and nonReentrant modifier'
      }
    ],
    targetAudience: 'DeFi protocol founders and smart contract engineers',
    temperature: 0.1,
    reasoningEffort: 'high',
    tags: ['web3', 'security']
  };

  const fullScore = calculateQualityScore(comprehensiveData, assemblePrompt(comprehensiveData));
  assert.ok(fullScore.overall >= 80, 'Comprehensive prompt should have high quality score');
  assert.ok(fullScore.clarity >= 80);
  assert.ok(fullScore.specificity >= 80);
});
