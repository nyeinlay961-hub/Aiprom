import type { PromptData, QualityScore, SavedPrompt } from '../types/prompt';

/**
 * Assembles a structured, high-performance system/user prompt from components.
 */
export function assemblePrompt(data: PromptData): string {
  const sections: string[] = [];

  // 1. Role & Identity
  if (data.role.trim()) {
    sections.push(`### ROLE & IDENTITY\nYou are an expert ${data.role.trim()}. You possess deep domain mastery, rigorous analytical thinking, and adhere to industry gold standards.`);
  }

  // 2. Primary Objective / Task
  if (data.task.trim()) {
    sections.push(`### OBJECTIVE & TASK\n${data.task.trim()}`);
  }

  // 3. Background & Context
  if (data.context.trim()) {
    sections.push(`### CONTEXT & BACKGROUND\n${data.context.trim()}`);
  }

  // 4. Target Audience
  if (data.targetAudience.trim()) {
    sections.push(`### TARGET AUDIENCE\nTailor tone, depth, and terminology specifically for: ${data.targetAudience.trim()}`);
  }

  // 5. Tone & Communication Style
  if (data.tone.trim()) {
    sections.push(`### TONE & COMMUNICATION STYLE\nAdopt a ${data.tone.trim()} style. Be precise, actionable, and eliminate unnecessary filler phrases.`);
  }

  // 6. Constraints & Guidelines
  const validConstraints = (data.constraints || []).map(c => c.trim()).filter(Boolean);
  if (validConstraints.length > 0) {
    const constraintList = validConstraints.map(c => `- ${c}`).join('\n');
    sections.push(`### CONSTRAINTS & NEGATIVE PROMPTS (MUST ADHERE TO)\n${constraintList}`);
  }

  // 7. Output Format & Structure
  if (data.outputFormat.trim()) {
    sections.push(`### OUTPUT FORMAT & SPECIFICATION\nFormat your response as: ${data.outputFormat.trim()}.\nEnsure strict formatting compliance, valid syntax, and clear hierarchy.`);
  }

  // 8. Few-Shot Examples
  const validExamples = (data.examples || []).filter(e => e.input.trim() || e.output.trim());
  if (validExamples.length > 0) {
    const examplesFormatted = validExamples.map((ex, index) => {
      return `[EXAMPLE ${index + 1}]\nInput:\n${ex.input.trim()}\n\nExpected Output:\n${ex.output.trim()}`;
    }).join('\n\n');
    sections.push(`### FEW-SHOT EXAMPLES\n${examplesFormatted}`);
  }

  // 9. Execution Parameters
  if (data.reasoningEffort === 'high') {
    sections.push(`### REASONING INSTRUCTIONS\nThink step-by-step before producing your final answer. Verify edge cases, cross-check facts, and refine your recommendations.`);
  }

  return sections.join('\n\n').trim();
}

/**
 * Estimates word, character and token counts for prompts.
 */
export function estimateTokens(text: string): { words: number; characters: number; tokens: number } {
  if (!text || text.trim().length === 0) {
    return { words: 0, characters: 0, tokens: 0 };
  }
  const clean = text.trim();
  const words = clean.split(/\s+/).filter(Boolean).length;
  const characters = clean.length;
  // Common heuristic for English/mixed technical text: ~1 token per 3.8 - 4 characters or ~0.75 words per token
  const tokens = Math.max(1, Math.round(characters / 3.8));
  return { words, characters, tokens };
}

/**
 * Evaluates prompt completeness, engineering best practices, and generates suggestions.
 */
export function calculateQualityScore(data: PromptData, assembled: string): QualityScore {
  const suggestions: string[] = [];

  // Clarity (Action verbs, task depth)
  let clarity = 40;
  if (data.task.trim().length >= 20) clarity += 25;
  if (data.task.trim().length >= 60) clarity += 20;
  const actionWords = ['create', 'design', 'analyze', 'explain', 'write', 'implement', 'evaluate', 'summarize', 'generate', 'build', 'review'];
  const hasActionVerb = actionWords.some(w => data.task.toLowerCase().includes(w));
  if (hasActionVerb) clarity += 15;
  if (clarity < 70) suggestions.push('Use stronger action verbs (e.g. "Design", "Critique", "Implement") in your primary task.');
  clarity = Math.min(100, clarity);

  // Specificity (Constraints, audience, negative rules)
  let specificity = 30;
  const validConstraints = (data.constraints || []).filter(c => c.trim().length > 0);
  if (validConstraints.length >= 1) specificity += 25;
  if (validConstraints.length >= 3) specificity += 20;
  if (data.targetAudience.trim().length > 0) specificity += 15;
  if (data.tone.trim().length > 0) specificity += 10;
  if (validConstraints.length === 0) {
    suggestions.push('Add at least 2 negative constraints (e.g. "Do not assume prior knowledge", "Avoid marketing jargon").');
  }
  if (!data.targetAudience.trim()) {
    suggestions.push('Define your target audience to calibrate depth and terminology.');
  }
  specificity = Math.min(100, specificity);

  // Context (Domain background, inputs)
  let contextScore = 30;
  if (data.role.trim().length >= 5) contextScore += 30;
  if (data.context.trim().length >= 30) contextScore += 25;
  if (data.context.trim().length >= 100) contextScore += 15;
  if (!data.role.trim()) {
    suggestions.push('Specify a dedicated persona/role (e.g. "Senior Principal Cloud Architect").');
  }
  if (data.context.trim().length < 30) {
    suggestions.push('Provide more domain background context or current system constraints.');
  }
  contextScore = Math.min(100, contextScore);

  // Structure (Output format, few-shot examples, sections)
  let structure = 40;
  if (data.outputFormat.trim().length > 0) structure += 30;
  const validExamples = (data.examples || []).filter(e => e.input.trim() || e.output.trim());
  if (validExamples.length >= 1) structure += 20;
  if (validExamples.length >= 2) structure += 10;
  if (!data.outputFormat.trim()) {
    suggestions.push('Explicitly define the required output structure (e.g. "Markdown table with columns A, B, C").');
  }
  if (validExamples.length === 0) {
    suggestions.push('Add a few-shot input/output example for reliable consistency.');
  }
  structure = Math.min(100, structure);

  // Overall weighted average
  const overall = Math.round(clarity * 0.3 + specificity * 0.25 + contextScore * 0.25 + structure * 0.2);

  return {
    overall,
    clarity,
    specificity,
    context: contextScore,
    structure,
    suggestions: suggestions.slice(0, 3)
  };
}

/**
 * Generates clean Markdown export for saved prompts.
 */
export function generateMarkdownExport(prompt: SavedPrompt): string {
  const parts = [
    `# Prompt: ${prompt.title}`,
    `**Category**: ${prompt.category} | **Created**: ${new Date(prompt.createdAt).toLocaleDateString()}`,
    prompt.tags.length > 0 ? `**Tags**: ${prompt.tags.map(t => `\`#${t}\``).join(' ')}` : '',
    prompt.notes ? `\n> **Notes**: ${prompt.notes}\n` : '',
    '---\n',
    '## Assembled Prompt for LLM',
    '```markdown',
    prompt.assembledPrompt,
    '```',
    '---\n',
    '## Metadata & Config',
    `- **Role**: ${prompt.data.role || 'Default'}`,
    `- **Tone**: ${prompt.data.tone || 'Neutral'}`,
    `- **Audience**: ${prompt.data.targetAudience || 'General'}`,
    `- **Output Format**: ${prompt.data.outputFormat || 'Freeform'}`,
    `- **Constraints Count**: ${prompt.data.constraints.length}`,
    `- **Few-shot Examples Count**: ${prompt.data.examples.length}`
  ];

  return parts.filter(Boolean).join('\n');
}
