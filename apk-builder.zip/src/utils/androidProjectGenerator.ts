import JSZip from 'jszip';
import type { AndroidBuildConfig } from '../types/prompt';

/**
 * Generates a full native Android project zip archive configured for compiling to an APK.
 */
export async function generateAndroidProjectZip(config: AndroidBuildConfig, appUrl: string): Promise<Blob> {
  const zip = new JSZip();

  const pkgParts = config.packageName.split('.');
  const pkgDir = pkgParts.join('/');

  // 1. Root build.gradle.kts
  const rootBuildGradle = `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
`;
  zip.file('build.gradle.kts', rootBuildGradle);

  // 2. settings.gradle.kts
  const settingsGradle = `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "${config.appName.replace(/[^a-zA-Z0-9_-]/g, '')}"
include(":app")
`;
  zip.file('settings.gradle.kts', settingsGradle);

  // 3. gradle.properties
  const gradleProperties = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
`;
  zip.file('gradle.properties', gradleProperties);

  // 4. gradle/wrapper/gradle-wrapper.properties
  const gradleWrapper = `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;
  zip.file('gradle/wrapper/gradle-wrapper.properties', gradleWrapper);

  // 5. app/build.gradle.kts
  const appBuildGradle = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${config.packageName}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${config.packageName}"
        minSdk = 24
        targetSdk = 34
        versionCode = ${config.versionCode}
        versionName = "${config.versionName}"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Change for production signing
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.webkit:webkit:1.10.0")
}
`;
  zip.file('app/build.gradle.kts', appBuildGradle);

  // 6. app/src/main/AndroidManifest.xml
  const orientationAttr = config.orientation === 'portrait' 
    ? 'android:screenOrientation="portrait"'
    : config.orientation === 'landscape'
    ? 'android:screenOrientation="landscape"'
    : 'android:screenOrientation="unspecified"';

  const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageName}">

    <!-- Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${config.appName}"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.${config.appName.replace(/[^a-zA-Z0-9]/g, '')}"
        android:hardwareAccelerated="${config.enableHardwareAcceleration}">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            ${orientationAttr}
            android:configChanges="orientation|keyboardHidden|screenSize"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
  zip.file('app/src/main/AndroidManifest.xml', manifest);

  // 7. MainActivity.kt with WebView
  const targetHostUrl = appUrl.startsWith('http') ? appUrl : `https://${appUrl}`;
  const mainActivity = `package ${config.packageName}

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar

    // Hosted application endpoint or local asset
    private val appUrl = "${targetHostUrl}"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)

        setupWebView()
        setupSwipeRefresh()

        if (savedInstanceState == null) {
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.displayZoomControls = false

        // Cache policy
        ${config.enableOfflineCache ? `
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = true
        ` : `
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        `}

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun setupSwipeRefresh() {
        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }
}
`;
  zip.file(`app/src/main/kotlin/${pkgDir}/MainActivity.kt`, mainActivity);

  // 8. res/layout/activity_main.xml
  const layoutXml = `<?xml version="1.0" encoding="utf-8"?>
<androidx.coordinatorlayout.widget.CoordinatorLayout 
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#020617">

    <ProgressBar
        android:id="@+id/progressBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="4dp"
        android:indeterminate="false"
        android:max="100"
        android:progressDrawable="@drawable/progress_bar"
        android:visibility="gone" />

    <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
        android:id="@+id/swipeRefresh"
        android:layout_width="match_parent"
        android:layout_height="match_parent">

        <WebView
            android:id="@+id/webView"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />

    </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>

</androidx.coordinatorlayout.widget.CoordinatorLayout>
`;
  zip.file('app/src/main/res/layout/activity_main.xml', layoutXml);

  // 9. res/values/styles.xml & colors.xml
  const themeName = config.appName.replace(/[^a-zA-Z0-9]/g, '');
  const stylesXml = `<resources>
    <style name="Theme.${themeName}" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">${config.themeColor}</item>
        <item name="colorPrimaryVariant">#3730a3</item>
        <item name="colorOnPrimary">#ffffff</item>
        <item name="android:statusBarColor">${config.themeColor}</item>
        <item name="android:navigationBarColor">#020617</item>
    </style>
</resources>
`;
  zip.file('app/src/main/res/values/styles.xml', stylesXml);

  const colorsXml = `<resources>
    <color name="primary">${config.themeColor}</color>
    <color name="background">#020617</color>
</resources>
`;
  zip.file('app/src/main/res/values/colors.xml', colorsXml);

  // 10. Automated GitHub Actions CI workflow to build APK automatically
  const githubWorkflow = `name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Grant execute permission for gradlew
        run: chmod +x gradlew || true

      - name: Build Debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Build Release APK
        run: ./gradlew assembleRelease --stacktrace

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-debug-apk
          path: app/build/outputs/apk/debug/*.apk

      - name: Upload Release APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: app/build/outputs/apk/release/*.apk
`;
  zip.file('.github/workflows/build-apk.yml', githubWorkflow);

  // 11. build-apk.sh script
  const buildScript = `#!/usr/bin/env bash
set -e

echo "=========================================="
echo " Building Android APK: ${config.appName} "
echo " Package: ${config.packageName} "
echo "=========================================="

if ! command -v ./gradlew &> /dev/null; then
  echo "Setting executable permission on gradlew..."
  chmod +x gradlew
fi

echo "Running ./gradlew assembleDebug..."
./gradlew assembleDebug

echo ""
echo "SUCCESS! Debug APK built at:"
echo "app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "To build a release APK, run: ./gradlew assembleRelease"
`;
  zip.file('build-apk.sh', buildScript);

  // 12. README instructions
  const readme = `# ${config.appName} - Android APK Build Project

This project contains the complete Android Native source code to compile **${config.appName}** into an Android APK.

## 🚀 3 Ways to Build Your APK

### Option 1: Instant WebAPK on Android (Zero Tooling Required)
1. Open this app's URL on Google Chrome for Android:
   \`${targetHostUrl}\`
2. Tap the **"Install App"** prompt at the top, or tap Chrome Menu (⋮) -> **"Install app"** / **"Add to Home screen"**.
3. Android and Google Play Services will automatically generate and install a native **WebAPK** package with its own app drawer icon, splash screen, and standalone process!

---

### Option 2: Build Locally with Android Studio / Terminal
1. Unzip this package.
2. Open terminal in this directory:
   \`\`\`bash
   chmod +x gradlew
   ./gradlew assembleDebug
   \`\`\`
3. Your compiled APK will be generated at:
   \`app/build/outputs/apk/debug/app-debug.apk\`
4. Install it to your connected Android phone or emulator:
   \`\`\`bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   \`\`\`

---

### Option 3: Free Cloud Build with GitHub Actions
1. Push this project to a GitHub repository.
2. Go to the **Actions** tab on your GitHub repo.
3. The included workflow (\`.github/workflows/build-apk.yml\`) will automatically build both **app-debug.apk** and **app-release.apk**.
4. Download the compiled APK directly from the GitHub Actions Artifacts list!

---

## ⚙️ Configuration
- **Package Name**: \`${config.packageName}\`
- **Version**: \`${config.versionName}\` (Code: ${config.versionCode})
- **Min SDK**: Android 7.0 (API 24)
- **Target SDK**: Android 14 (API 34)
- **Theme Color**: \`${config.themeColor}\`
`;
  zip.file('README.md', readme);

  return await zip.generateAsync({ type: 'blob' });
}
