export interface FewShotExample {
  id: string;
  input: string;
  output: string;
}

export interface PromptData {
  role: string;
  task: string;
  context: string;
  tone: string;
  constraints: string[];
  outputFormat: string;
  examples: FewShotExample[];
  targetAudience: string;
  temperature: number;
  reasoningEffort: 'low' | 'medium' | 'high';
  tags: string[];
}

export interface SavedPrompt {
  id: string;
  title: string;
  data: PromptData;
  assembledPrompt: string;
  createdAt: string;
  updatedAt: string;
  category: string;
  favorite: boolean;
  tags: string[];
  notes?: string;
}

export interface PresetTemplate {
  id: string;
  name: string;
  category: 'development' | 'marketing' | 'writing' | 'analysis' | 'education' | 'system';
  description: string;
  badge: string;
  data: PromptData;
}

export interface QualityScore {
  overall: number; // 0 - 100
  clarity: number; // 0 - 100
  specificity: number; // 0 - 100
  context: number; // 0 - 100
  structure: number; // 0 - 100
  suggestions: string[];
}

export interface AndroidBuildConfig {
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  themeColor: string;
  orientation: 'portrait' | 'landscape' | 'sensor';
  enableOfflineCache: boolean;
  enableHardwareAcceleration: boolean;
  permissions: string[];
}
