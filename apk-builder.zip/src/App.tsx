import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { PromptBuilder } from './components/PromptBuilder';
import { PromptPreview } from './components/PromptPreview';
import { SavedPromptsScreen } from './components/SavedPromptsScreen';
import { AndroidApkModal } from './components/AndroidApkModal';
import { AiTestModal } from './components/AiTestModal';
import { TemplatesModal } from './components/TemplatesModal';
import { SavePromptModal } from './components/SavePromptModal';
import { DEFAULT_PROMPT_DATA, PRESET_TEMPLATES } from './data/presets';
import { assemblePrompt, calculateQualityScore } from './utils/promptUtils';
import type { PromptData, SavedPrompt, PresetTemplate } from './types/prompt';
import { Smartphone, Sparkles } from 'lucide-react';

const STORAGE_KEY = 'prompt_builder_pro_saved_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'saved' | 'templates'>('studio');
  const [promptData, setPromptData] = useState<PromptData>(DEFAULT_PROMPT_DATA);
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>([]);
  
  // Modals
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [isTemplatesModalOpen, setIsTemplatesModalOpen] = useState(false);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);

  // PWA Install prompt state
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  // Toast notification
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 3000);
  };

  // Listen to PWA install event
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Check query params for quick navigation (e.g. ?tab=apk or ?tab=saved)
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    if (tabParam === 'apk') {
      setIsApkModalOpen(true);
    } else if (tabParam === 'saved') {
      setActiveTab('saved');
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // Load saved prompts from localStorage with seed defaults
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setSavedPrompts(parsed);
          return;
        }
      }

      // Seed with initial presets if empty
      const initialSeed: SavedPrompt[] = PRESET_TEMPLATES.slice(0, 3).map((tpl, i) => ({
        id: `seed-${tpl.id}`,
        title: tpl.name,
        data: tpl.data,
        assembledPrompt: assemblePrompt(tpl.data),
        createdAt: new Date(Date.now() - (i + 1) * 86400000).toISOString(),
        updatedAt: new Date().toISOString(),
        category: tpl.category,
        favorite: i === 0,
        tags: tpl.data.tags,
        notes: tpl.description,
      }));

      setSavedPrompts(initialSeed);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialSeed));
    } catch (e) {
      console.warn('Failed to load saved prompts from storage', e);
    }
  }, []);

  // Save to localStorage whenever savedPrompts changes
  const updateSavedPrompts = (updater: (prev: SavedPrompt[]) => SavedPrompt[]) => {
    setSavedPrompts((prev) => {
      const next = updater(prev);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch (e) {
        console.error('Failed to sync saved prompts to storage', e);
      }
      return next;
    });
  };

  // Assembled prompt and real-time score
  const assembledPrompt = useMemo(() => assemblePrompt(promptData), [promptData]);
  const qualityScore = useMemo(
    () => calculateQualityScore(promptData, assembledPrompt),
    [promptData, assembledPrompt]
  );

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstallable(false);
      }
      setDeferredPrompt(null);
    } else {
      setIsApkModalOpen(true);
    }
  };

  const handleSavePrompt = (newPrompt: SavedPrompt) => {
    updateSavedPrompts((prev) => [newPrompt, ...prev]);
    showToast(`Saved "${newPrompt.title}" to library!`);
  };

  const handleDeletePrompt = (id: string) => {
    updateSavedPrompts((prev) => prev.filter((p) => p.id !== id));
    showToast('Prompt deleted.');
  };

  const handleToggleFavorite = (id: string) => {
    updateSavedPrompts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, favorite: !p.favorite } : p))
    );
  };

  const handleLoadPrompt = (saved: SavedPrompt) => {
    setPromptData(saved.data);
    setActiveTab('studio');
    showToast(`Loaded "${saved.title}" into Studio`);
  };

  const handleSelectTemplate = (template: PresetTemplate) => {
    setPromptData(template.data);
    setActiveTab('studio');
    showToast(`Applied preset: ${template.name}`);
  };

  const handleNewPrompt = () => {
    setPromptData({
      role: '',
      task: '',
      context: '',
      tone: 'Professional & Direct',
      constraints: [],
      outputFormat: 'Markdown structure',
      examples: [],
      targetAudience: '',
      temperature: 0.4,
      reasoningEffort: 'medium',
      tags: [],
    });
    setActiveTab('studio');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold shadow-xl border border-indigo-400/30 animate-fade-in flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-200" />
          <span>{toast}</span>
        </div>
      )}

      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onNewPrompt={handleNewPrompt}
        savedCount={savedPrompts.length}
        isInstallable={isInstallable}
        onInstallApp={handleInstallApp}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Studio View */}
        {activeTab === 'studio' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Form Builder (7 cols) */}
            <div className="lg:col-span-7 bg-slate-950 rounded-2xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
                    Prompt Engineering Studio
                  </h1>
                  <p className="text-xs text-slate-400">
                    Construct persona-driven, constraint-bound system prompts with live evaluation.
                  </p>
                </div>
                <button
                  onClick={() => setIsTemplatesModalOpen(true)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-indigo-400 hover:text-indigo-300 text-xs font-semibold border border-slate-800 transition"
                >
                  Browse Presets
                </button>
              </div>

              <PromptBuilder
                data={promptData}
                onChange={setPromptData}
                qualityScore={qualityScore}
                onApplyPreset={() => setIsTemplatesModalOpen(true)}
              />
            </div>

            {/* Right Column: Live Preview & Action Bar (5 cols) */}
            <div className="lg:col-span-5 sticky top-20">
              <PromptPreview
                assembledPrompt={assembledPrompt}
                data={promptData}
                onOpenSaveModal={() => setIsSaveModalOpen(true)}
                onOpenTestModal={() => setIsTestModalOpen(true)}
                onOpenApkModal={() => setIsApkModalOpen(true)}
              />
            </div>
          </div>
        )}

        {/* Saved Prompts Library View (Equivalent to Flutter saved_screen.dart) */}
        {activeTab === 'saved' && (
          <SavedPromptsScreen
            prompts={savedPrompts}
            onLoadPrompt={handleLoadPrompt}
            onDeletePrompt={handleDeletePrompt}
            onToggleFavorite={handleToggleFavorite}
            onImportPrompts={(imported) => {
              updateSavedPrompts((prev) => [...imported, ...prev]);
              showToast(`Imported ${imported.length} prompts!`);
            }}
            onNewPrompt={handleNewPrompt}
          />
        )}

        {/* Templates Presets View */}
        {activeTab === 'templates' && (
          <div className="space-y-6">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">
                  Curated Prompt Architectures
                </h2>
                <p className="text-xs text-slate-400">
                  Select a production-grade template to load into your Studio workbench.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('studio')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                Back to Studio
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {PRESET_TEMPLATES.map((tpl) => (
                <div
                  key={tpl.id}
                  className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 flex flex-col justify-between transition group space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                        {tpl.badge}
                      </span>
                      <span className="text-[11px] text-slate-500 capitalize">
                        {tpl.category}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-100 group-hover:text-indigo-300 transition mb-1">
                      {tpl.name}
                    </h3>

                    <p className="text-xs text-slate-400 leading-relaxed mb-3">
                      {tpl.description}
                    </p>

                    <div className="flex flex-wrap gap-1">
                      {tpl.data.tags.map((t, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400"
                        >
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleSelectTemplate(tpl)}
                      className="flex-1 py-2 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition text-center"
                    >
                      Use in Studio
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(assemblePrompt(tpl.data));
                        showToast(`Copied "${tpl.name}" prompt!`);
                      }}
                      className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
                      title="Copy assembled prompt"
                    >
                      Copy
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Modals */}
      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
        isInstallable={isInstallable}
        onInstallApp={handleInstallApp}
      />

      <AiTestModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        assembledPrompt={assembledPrompt}
      />

      <TemplatesModal
        isOpen={isTemplatesModalOpen}
        onClose={() => setIsTemplatesModalOpen(false)}
        onSelectTemplate={handleSelectTemplate}
      />

      <SavePromptModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        data={promptData}
        assembledPrompt={assembledPrompt}
        onSave={handleSavePrompt}
      />
    </div>
  );
}
