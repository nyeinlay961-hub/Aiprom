import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register service worker for offline and Android PWA installability
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => {
      // Non-blocking registration log
      console.debug('ServiceWorker notice:', err);
    });
  });
}

createRoot(document.getElementById('root')!).render(<App />);
